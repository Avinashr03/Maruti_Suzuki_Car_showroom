<html>
<head>
<title>Maruti Suzuki Driving School</title>

</head>

<body>
<center><h1>Maruti Suzuki Driving School</h1></center>
<img src="ads01.png">
<center><h2>CHOOSE YOUR COURSE TO DRIVE WITH CONFIDENCE ON THE ROAD</h1></center>
<p>Our meticulously designed courses help transform beginners into skilled and confident drivers. Choose your desired course from a range of driving training courses and master the skill of driving at Maruti Suzuki Driving School.</p>
<img src="ads03.png">    <img src="ads04.png">
<font face="times new roman" size="3"><center><h1>APPLICATION FOR MS DRIVING SCHOOL <center></h2>
<form action="pdf.php" method="POST">
    <pre>
Name                    <input type="text" placeholder="name" name="name">

Phone number      <input type="number" placeholder="Phone_number" name="Phone_number">

Email address       <input type="text" placeholder="email" name="email">

Driving Vehicle             <input type="text" placeholder="vehicle_type" name="vehicle">        

Car (Four - Wheeler)  (or)  Bike (Two  - Wheeler)  (or)  Both

      
    <input type="submit" id="button" name="submit">

</font>
    </pre>
</form>
</body>
</html>

